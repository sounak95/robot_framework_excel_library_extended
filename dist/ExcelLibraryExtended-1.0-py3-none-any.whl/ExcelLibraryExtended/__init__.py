from .ExcelLibraryExtended import ExcelLibraryExtended
from .version import VERSION
__version__ = VERSION